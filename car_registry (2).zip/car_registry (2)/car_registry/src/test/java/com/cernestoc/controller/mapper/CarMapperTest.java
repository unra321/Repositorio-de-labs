package com.cernestoc.controller.mapper;

public class CarMapperTest {
}
